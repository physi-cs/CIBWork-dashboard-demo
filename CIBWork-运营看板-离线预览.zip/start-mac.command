#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required to preview this dashboard."
  echo "Install Python 3, then run this file again."
  read -r -p "Press Enter to close this window."
  exit 1
fi

exec python3 - "$ROOT_DIR" <<'PYTHON'
import functools
import os
import subprocess
import sys
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

site_root = os.path.realpath(sys.argv[1])
handler = functools.partial(SimpleHTTPRequestHandler, directory=site_root)
server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
server.daemon_threads = True
url = "http://127.0.0.1:{}/".format(server.server_address[1])
print("CIBWork local preview: {}".format(url), flush=True)
print("Keep this window open. Press Ctrl+C to stop.", flush=True)
threading.Timer(0.7, lambda: subprocess.Popen(["open", url])).start()
try:
    server.serve_forever()
except KeyboardInterrupt:
    print("\nPreview stopped.", flush=True)
finally:
    server.server_close()
PYTHON