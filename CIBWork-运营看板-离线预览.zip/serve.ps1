$ErrorActionPreference = 'Stop'
$siteRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$rootPrefix = $siteRoot.TrimEnd([System.IO.Path]::DirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
$listener.Start()
$port = ([System.Net.IPEndPoint]$listener.LocalEndpoint).Port
$url = "http://127.0.0.1:$port/"
Write-Host "CIBWork local preview: $url" -ForegroundColor Cyan
Write-Host 'Keep this window open. Press Ctrl+C to stop.' -ForegroundColor Gray
Start-Process $url
try {
  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $stream = $client.GetStream()
      $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
      $requestLine = $reader.ReadLine()
      if ([string]::IsNullOrEmpty($requestLine)) { $reader.Dispose(); $client.Close(); continue }
      while ($true) { $headerLine = $reader.ReadLine(); if ([string]::IsNullOrEmpty($headerLine)) { break } }
      $reader.Dispose()
      $parts = [regex]::Split($requestLine.Trim(), '\s+', 3)
      $method = $parts[0]
      $requestTarget = if ($parts.Length -gt 1) { $parts[1] } else { '/' }
      $pathOnly = ($requestTarget -split '[?#]', 2)[0]
      $relative = [System.Uri]::UnescapeDataString($pathOnly.TrimStart('/').Replace('/', [System.IO.Path]::DirectorySeparatorChar))
      if ([string]::IsNullOrWhiteSpace($relative)) { $relative = 'index.html' }
      $filePath = [System.IO.Path]::GetFullPath((Join-Path $siteRoot $relative))
      $status = '200 OK'
      $body = $null
      $mime = 'text/plain; charset=utf-8'
      if (-not $filePath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        $status = '403 Forbidden'
        $body = [System.Text.Encoding]::UTF8.GetBytes('Forbidden')
      } else {
        if ($method -notin @('GET', 'HEAD')) {
          $status = '405 Method Not Allowed'
          $body = [System.Text.Encoding]::UTF8.GetBytes('Method Not Allowed')
        } else {
          if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) {
            $status = '404 Not Found'
            $body = [System.Text.Encoding]::UTF8.GetBytes('Not Found')
          } else {
            $mime = switch ([System.IO.Path]::GetExtension($filePath).ToLowerInvariant()) {
              '.html' { 'text/html; charset=utf-8' }
              '.js' { 'text/javascript; charset=utf-8' }
              '.css' { 'text/css; charset=utf-8' }
              '.svg' { 'image/svg+xml' }
              '.json' { 'application/json; charset=utf-8' }
              '.png' { 'image/png' }
              '.jpg' { 'image/jpeg' }
              '.jpeg' { 'image/jpeg' }
              '.woff' { 'font/woff' }
              '.woff2' { 'font/woff2' }
              '.ico' { 'image/x-icon' }
              default { 'application/octet-stream' }
            }
          }
        }
      }
      if ($null -ne $body) { $length = $body.Length } else { $length = (Get-Item -LiteralPath $filePath).Length }
      $header = [System.Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $status`r`nContent-Type: $mime`r`nContent-Length: $length`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n")
      $stream.Write($header, 0, $header.Length)
      if ($method -ne 'HEAD') {
        if ($null -ne $body) {
          $stream.Write($body, 0, $body.Length)
        } else {
          $file = [System.IO.File]::OpenRead($filePath)
          try { $file.CopyTo($stream) } finally { $file.Dispose() }
        }
      }
      $stream.Flush()
      $client.Close()
    } catch { try { $client.Close() } catch {} }
  }
} finally { $listener.Stop() }